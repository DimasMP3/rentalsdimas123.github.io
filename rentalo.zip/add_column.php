<?php

// Load the database configuration
require 'app/Config/Database.php';

// Create a database connection
$config = new \Config\Database();
$db = \Config\Database::connect();

// Add the is_approved column to the reviews table
$db->query("ALTER TABLE reviews ADD COLUMN is_approved BOOLEAN DEFAULT 0 AFTER comment;");

echo "Column 'is_approved' has been added to the 'reviews' table successfully."; 