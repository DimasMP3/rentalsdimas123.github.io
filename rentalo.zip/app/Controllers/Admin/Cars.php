<?php

namespace App\Controllers\Admin;

use App\Controllers\Admin\BaseController;
use App\Models\CarModel;
use App\Models\CategoryModel;
use App\Models\ReviewModel;

class Cars extends BaseController
{
    public function index()
    {
        $carModel = new CarModel();
        
        $data = [
            'title' => 'Manage Cars',
            'cars' => $carModel->findAll()
        ];
        
        return view('admin/cars/index', $data);
    }
    
    public function create()
    {
        $categoryModel = new CategoryModel();
        
        $data = [
            'title' => 'Add New Car',
            'categories' => $categoryModel->findAll()
        ];
        
        return view('admin/cars/create', $data);
    }
    
    public function store()
    {
        $rules = [
            'brand' => 'required',
            'model' => 'required',
            'year' => 'required|numeric',
            'license_plate' => 'required|is_unique[cars.license_plate]',
            'daily_rate' => 'required|numeric',
            'category_id' => 'required|numeric',
            'image' => 'uploaded[image]|max_size[image,4096]|is_image[image]'
        ];
        
        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
        $carModel = new CarModel();
        
        // Handle image upload
        $image = $this->request->getFile('image');
        $imageName = $image->getRandomName();
        $image->move(ROOTPATH . 'public/uploads/cars', $imageName);
        
        $data = [
            'brand' => $this->request->getPost('brand'),
            'model' => $this->request->getPost('model'),
            'year' => $this->request->getPost('year'),
            'license_plate' => $this->request->getPost('license_plate'),
            'daily_rate' => $this->request->getPost('daily_rate'),
            'description' => $this->request->getPost('description'),
            'image' => $imageName,
            'status' => 'available',
            'category_id' => $this->request->getPost('category_id')
        ];
        
        $carModel->insert($data);
        
        return redirect()->to('/admin/cars')->with('success', 'Car added successfully');
    }
    
    public function edit($id)
    {
        $carModel = new CarModel();
        $categoryModel = new CategoryModel();
        
        $car = $carModel->find($id);
        
        if (!$car) {
            return redirect()->to('/admin/cars')->with('error', 'Car not found');
        }
        
        $data = [
            'title' => 'Edit Car',
            'car' => $car,
            'categories' => $categoryModel->findAll()
        ];
        
        return view('admin/cars/edit', $data);
    }
    
    public function update($id)
    {
        $rules = [
            'brand' => 'required',
            'model' => 'required',
            'year' => 'required|numeric',
            'license_plate' => 'required',
            'daily_rate' => 'required|numeric',
            'category_id' => 'required|numeric',
            'status' => 'required'
        ];
        
        // Check if license plate is unique except for this car
        $carModel = new CarModel();
        $car = $carModel->find($id);
        
        if ($car['license_plate'] != $this->request->getPost('license_plate')) {
            $rules['license_plate'] .= '|is_unique[cars.license_plate]';
        }
        
        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
        $data = [
            'brand' => $this->request->getPost('brand'),
            'model' => $this->request->getPost('model'),
            'year' => $this->request->getPost('year'),
            'license_plate' => $this->request->getPost('license_plate'),
            'daily_rate' => $this->request->getPost('daily_rate'),
            'description' => $this->request->getPost('description'),
            'status' => $this->request->getPost('status'),
            'category_id' => $this->request->getPost('category_id')
        ];
        
        // Handle image upload if a new image is provided
        $image = $this->request->getFile('image');
        if ($image->isValid() && !$image->hasMoved()) {
            $imageName = $image->getRandomName();
            $image->move(ROOTPATH . 'public/uploads/cars', $imageName);
            $data['image'] = $imageName;
            
            // Delete old image
            if ($car['image'] && file_exists(ROOTPATH . 'public/uploads/cars/' . $car['image'])) {
                unlink(ROOTPATH . 'public/uploads/cars/' . $car['image']);
            }
        }
        
        try {
            $carModel->update($id, $data);
            return redirect()->to('/admin/cars')->with('success', 'Car updated successfully');
        } catch (\Exception $e) {
            return redirect()->back()->withInput()->with('errors', ['Failed to update car: ' . $e->getMessage()]);
        }
    }
    
    public function delete($id)
    {
        $carModel = new CarModel();
        
        $car = $carModel->find($id);
        
        if (!$car) {
            return redirect()->to('/admin/cars')->with('error', 'Car not found');
        }
        
        // Delete image
        if ($car['image'] && file_exists(ROOTPATH . 'public/uploads/cars/' . $car['image'])) {
            unlink(ROOTPATH . 'public/uploads/cars/' . $car['image']);
        }
        
        $carModel->delete($id);
        
        return redirect()->to('/admin/cars')->with('success', 'Car deleted successfully');
    }

    public function detail($id)
    {
        $carModel = new \App\Models\CarModel();
        $reviewModel = new \App\Models\ReviewModel();
        
        $car = $carModel->find($id);
        
        if (!$car) {
            session()->setFlashdata('error', 'Mobil tidak ditemukan.');
            return redirect()->to('admin/cars');
        }
        
        $reviews = $reviewModel->getReviewsWithUser($id);
        
        $data = [
            'title' => 'Detail Mobil',
            'car' => $car,
            'reviews' => $reviews
        ];
        
        return view('admin/cars/detail', $data);
    }
}

