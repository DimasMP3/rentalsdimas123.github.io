<?php

namespace App\Controllers\Admin;

use App\Controllers\Admin\BaseController;
use App\Models\OrderModel;
use App\Models\CarModel;
use App\Models\UserModel;

class Orders extends BaseController
{
    public function index()
    {
        $orderModel = new OrderModel();
        
        $data = [
            'title' => 'Manage Orders',
            'orders' => $orderModel->select('orders.*, cars.brand, cars.model, users.name as user_name')
                                 ->join('cars', 'cars.id = orders.car_id')
                                 ->join('users', 'users.id = orders.user_id')
                                 ->findAll()
        ];
        
        return view('admin/orders/index', $data);
    }
    
    public function show($id)
    {
        $orderModel = new OrderModel();
        $order = $orderModel->select('orders.*, cars.brand, cars.model, cars.image, cars.year, cars.license_plate, cars.daily_rate, cars.description, users.name as user_name, users.email as user_email, users.phone as user_phone')
                          ->join('cars', 'cars.id = orders.car_id')
                          ->join('users', 'users.id = orders.user_id')
                          ->find($id);
        
        if (!$order) {
            return redirect()->to('/admin/orders')->with('error', 'Order not found');
        }
        
        $data = [
            'title' => 'Order Details',
            'order' => $order
        ];
        
        return view('admin/orders/show', $data);
    }
    
    public function updateStatus($id)
    {
        $orderModel = new OrderModel();
        $order = $orderModel->find($id);
        
        if (!$order) {
            return redirect()->to('/admin/orders')->with('error', 'Order not found');
        }
        
        $status = $this->request->getPost('status');
        $carModel = new CarModel();
        
        // Update order status
        $orderModel->update($id, ['status' => $status]);
        
        // Update car status based on order status
        if ($status === 'approved') {
            $carModel->update($order['car_id'], ['status' => 'rented']);
        } elseif ($status === 'completed') {
            $carModel->update($order['car_id'], ['status' => 'available']);
        }
        
        return redirect()->to('/admin/orders')->with('success', 'Order status updated successfully');
    }
} 