<?php

namespace App\Controllers\Admin;

use App\Controllers\Admin\BaseController;
use App\Models\Admin\PaymentManagementModel;

class Payments extends BaseController
{
    protected $paymentModel;
    
    public function __construct()
    {
        $this->paymentModel = new PaymentManagementModel();
    }
    
    public function index()
    {
        $data = [
            'title' => 'Pengelolaan Pembayaran',
            'payments' => $this->paymentModel->getAllPaymentsWithDetails()
        ];
        
        return view('admin/payments/index', $data);
    }
    
    public function show($id)
    {
        $payment = $this->paymentModel->getPaymentDetails($id);
        
        if (!$payment) {
            return redirect()->to('/admin/payments')->with('error', 'Data pembayaran tidak ditemukan');
        }
        
        $data = [
            'title' => 'Detail Pembayaran',
            'payment' => $payment
        ];
        
        return view('admin/payments/show', $data);
    }
    
    public function updateStatus($id)
    {
        $status = $this->request->getPost('status');
        $note = $this->request->getPost('note');
        
        if (!in_array($status, ['pending', 'processing', 'completed', 'failed', 'refunded'])) {
            return redirect()->back()->with('error', 'Status pembayaran tidak valid');
        }
        
        $data = [
            'status' => $status
        ];
        
        if ($note) {
            $data['notes'] = $note;
        }
        
        if ($this->paymentModel->update($id, $data)) {
            // Jika status pembayaran selesai, update status rental
            if ($status == 'completed') {
                $payment = $this->paymentModel->getPaymentDetails($id);
                if ($payment) {
                    $rentalModel = model('RentalModel');
                    $rentalModel->update($payment['rental_id'], ['payment_status' => 'paid']);
                }
            }
            
            return redirect()->to('/admin/payments')->with('success', 'Status pembayaran berhasil diperbarui');
        } else {
            return redirect()->back()->with('error', 'Gagal memperbarui status pembayaran');
        }
    }
    
    public function filter()
    {
        $status = $this->request->getGet('status');
        $startDate = $this->request->getGet('start_date');
        $endDate = $this->request->getGet('end_date');
        
        $db = \Config\Database::connect();
        $builder = $db->table('payments')
                      ->select('payments.*, rentals.pickup_date, rentals.return_date, users.name as user_name, cars.brand, cars.model')
                      ->join('rentals', 'rentals.id = payments.rental_id')
                      ->join('users', 'users.id = rentals.user_id')
                      ->join('cars', 'cars.id = rentals.car_id');
        
        if ($status && $status != 'all') {
            $builder->where('payments.status', $status);
        }
        
        if ($startDate) {
            $builder->where('payments.created_at >=', $startDate . ' 00:00:00');
        }
        
        if ($endDate) {
            $builder->where('payments.created_at <=', $endDate . ' 23:59:59');
        }
        
        $payments = $builder->orderBy('payments.created_at', 'DESC')
                            ->get()
                            ->getResultArray();
        
        $data = [
            'title' => 'Filter Pembayaran',
            'payments' => $payments,
            'status' => $status,
            'start_date' => $startDate,
            'end_date' => $endDate
        ];
        
        return view('admin/payments/filter', $data);
    }
    
    public function exportCsv()
    {
        $status = $this->request->getGet('status');
        $startDate = $this->request->getGet('start_date');
        $endDate = $this->request->getGet('end_date');
        
        $db = \Config\Database::connect();
        $builder = $db->table('payments')
                      ->select('payments.id, payments.amount, payments.payment_method, payments.status, payments.created_at, users.name as user_name, cars.brand, cars.model, rentals.pickup_date, rentals.return_date')
                      ->join('rentals', 'rentals.id = payments.rental_id')
                      ->join('users', 'users.id = rentals.user_id')
                      ->join('cars', 'cars.id = rentals.car_id');
        
        if ($status && $status != 'all') {
            $builder->where('payments.status', $status);
        }
        
        if ($startDate) {
            $builder->where('payments.created_at >=', $startDate . ' 00:00:00');
        }
        
        if ($endDate) {
            $builder->where('payments.created_at <=', $endDate . ' 23:59:59');
        }
        
        $payments = $builder->orderBy('payments.created_at', 'DESC')
                            ->get()
                            ->getResultArray();
        
        // Set header untuk download CSV
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="payments_export.csv"');
        
        // Buat file pointer untuk output
        $output = fopen('php://output', 'w');
        
        // Buat header CSV
        fputcsv($output, ['ID', 'User', 'Mobil', 'Tanggal Mulai', 'Tanggal Selesai', 'Jumlah', 'Metode Pembayaran', 'Status', 'Tanggal Pembayaran']);
        
        // Tulis data ke CSV
        foreach ($payments as $payment) {
            fputcsv($output, [
                $payment['id'],
                $payment['user_name'],
                $payment['brand'] . ' ' . $payment['model'],
                $payment['pickup_date'],
                $payment['return_date'],
                $payment['amount'],
                $payment['payment_method'],
                $payment['status'],
                $payment['created_at']
            ]);
        }
        
        fclose($output);
        exit;
    }
} 