<?php

namespace App\Controllers\Admin;

use App\Controllers\Admin\BaseController;
use App\Models\Admin\ReviewManagementModel;

class Reviews extends BaseController
{
    protected $reviewModel;
    
    public function __construct()
    {
        $this->reviewModel = new ReviewManagementModel();
    }
    
    public function index()
    {
        $data = [
            'title' => 'Manajemen Ulasan',
            'reviews' => $this->reviewModel->getAllReviewsWithDetails()
        ];
        
        return view('admin/reviews/index', $data);
    }
    
    public function detail($id)
    {
        $data = [
            'title' => 'Detail Ulasan',
            'review' => $this->reviewModel->getReviewDetails($id)
        ];
        
        return view('admin/reviews/detail', $data);
    }
    
    public function approve($id)
    {
        $this->reviewModel->approveReview($id);
        
        session()->setFlashdata('success', 'Ulasan berhasil disetujui.');
        return redirect()->to('/admin/reviews');
    }
    
    public function delete($id)
    {
        $this->reviewModel->deleteReview($id);
        
        session()->setFlashdata('success', 'Ulasan berhasil dihapus.');
        return redirect()->to('/admin/reviews');
    }
} 