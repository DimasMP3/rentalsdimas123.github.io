<?php

namespace App\Controllers;

use App\Models\UserModel;

class Auth extends BaseController
{
    public function __construct()
    {
        helper(['form', 'url']);
    }

    public function login()
    {
        if (session()->get('isLoggedIn')) {
            return redirect()->to('/');
        }
        
        return view('auth/login', ['title' => 'Login']);
    }
    
    public function attemptLogin()
    {
        $rules = [
            'email' => 'required|valid_email',
            'password' => 'required|min_length[6]'
        ];
        
        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
        $userModel = new UserModel();
        
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');
        
        $user = $userModel->where('email', $email)->first();
        
        if (!$user || !password_verify($password, $user['password'])) {
            return redirect()->back()->withInput()->with('error', 'Email atau password salah. Silakan coba lagi.');
        }
        
        // Check if user is active
        if ($user['status'] == 'inactive') {
            return redirect()->back()->withInput()->with('error', 'Akun Anda tidak aktif. Silakan hubungi admin.');
        }
        
        // Set session
        $this->setUserSession($user);
        
        // Redirect based on role
        if ($user['role'] == 'admin') {
            return redirect()->to('/admin/dashboard')->with('success', 'Selamat datang, Admin!');
        } else {
            return redirect()->to('/rentals')->with('success', 'Login berhasil!');
        }
    }
    
    public function register()
    {
        if (session()->get('isLoggedIn')) {
            return redirect()->to('/');
        }
        
        return view('auth/register', ['title' => 'Register']);
    }
    
    public function attemptRegister()
    {
        $rules = [
            'name' => 'required|min_length[3]',
            'email' => 'required|valid_email|is_unique[users.email]',
            'password' => 'required|min_length[6]',
            'password_confirm' => 'required|matches[password]',
            'phone' => 'required',
            'address' => 'required',
            'license_number' => 'required'
        ];
        
        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
        $userModel = new UserModel();
        
        $data = [
            'name' => $this->request->getPost('name'),
            'email' => $this->request->getPost('email'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
            'phone' => $this->request->getPost('phone'),
            'address' => $this->request->getPost('address'),
            'license_number' => $this->request->getPost('license_number'),
            'role' => 'user',
            'status' => 'active'
        ];
        
        $userModel->insert($data);
        
        return redirect()->to('/login')->with('success', 'Pendaftaran berhasil. Silakan login dengan akun Anda.');
    }
    
    public function logout()
    {
        session()->destroy();
        return redirect()->to('/');
    }
    
    private function setUserSession($user)
    {
        $data = [
            'user_id' => $user['id'],
            'name' => $user['name'],
            'email' => $user['email'],
            'role' => $user['role'],
            'isLoggedIn' => true
        ];
        
        session()->set($data);
        return true;
    }
}

