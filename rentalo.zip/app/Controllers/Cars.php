<?php

namespace App\Controllers;

use App\Models\CarModel;
use App\Models\CategoryModel;
use App\Models\ReviewModel;

class Cars extends BaseController
{
    public function index()
    {
        $carModel = new CarModel();
        $categoryModel = new CategoryModel();
        
        // Get filter parameters
        $category = $this->request->getGet('category');
        $minPrice = $this->request->getGet('min_price');
        $maxPrice = $this->request->getGet('max_price');
        
        // Apply filters
        if ($category) {
            $carModel->where('category_id', $category);
        }
        
        if ($minPrice) {
            $carModel->where('daily_rate >=', $minPrice);
        }
        
        if ($maxPrice) {
            $carModel->where('daily_rate <=', $maxPrice);
        }
        
        $data = [
            'title' => 'Available Cars',
            'cars' => $carModel->where('status', 'available')->findAll(),
            'categories' => $categoryModel->findAll()
        ];
        
        return view('cars/index', $data);
    }
    
    public function show($id)
    {
        $carModel = new CarModel();
        $reviewModel = new ReviewModel();
        
        $car = $carModel->find($id);
        
        if (!$car) {
            return redirect()->to('/cars')->with('error', 'Car not found');
        }
        
        $data = [
            'title' => $car['brand'] . ' ' . $car['model'],
            'car' => $car,
            'reviews' => $reviewModel->where('car_id', $id)->findAll()
        ];
        
        return view('cars/show', $data);
    }
    
    public function byCategory($categoryId)
    {
        $carModel = new CarModel();
        $categoryModel = new CategoryModel();
        
        $category = $categoryModel->find($categoryId);
        
        if (!$category) {
            return redirect()->to('/cars')->with('error', 'Category not found');
        }
        
        $data = [
            'title' => 'Cars in ' . $category['name'] . ' Category',
            'cars' => $carModel->where('category_id', $categoryId)->where('status', 'available')->findAll(),
            'categories' => $categoryModel->findAll(),
            'current_category' => $category
        ];
        
        return view('cars/index', $data);
    }
}