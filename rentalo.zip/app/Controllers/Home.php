<?php

namespace App\Controllers;

use App\Models\CarModel;
use App\Models\CategoryModel;

class Home extends BaseController
{
    public function index()
    {
        $carModel = new CarModel();
        $categoryModel = new CategoryModel();
        
        $data = [
            'title' => 'Welcome to CarRent - Your Premium Car Rental Service',
            'cars' => $carModel->where('status', 'available')->findAll(6),
            'categories' => $categoryModel->findAll(),
            'featured_cars' => $carModel->where('status', 'available')->orderBy('RAND()')->findAll(8)
        ];
        
        file_put_contents('log.txt', json_encode($data));
        return view('home', $data);
    }
}

