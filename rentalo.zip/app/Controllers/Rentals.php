<?php

namespace App\Controllers;

use App\Models\CarModel;
use App\Models\OrderModel;
use App\Models\PaymentModel;

class Rentals extends BaseController
{
    protected $carModel;
    protected $orderModel;
    protected $paymentModel;
    
    public function __construct()
    {
        $this->carModel = new CarModel();
        $this->orderModel = new OrderModel();
        $this->paymentModel = new PaymentModel();
    }
    
    public function index()
    {
        $data = [
            'title' => 'My Rentals',
            'orders' => $this->orderModel->getOrdersByUser(session()->get('user_id'))
        ];
        
        return view('rentals/index', $data);
    }
    
    public function create($carId)
    {
        $car = $this->carModel->find($carId);
        
        if (!$car || $car['status'] != 'available') {
            return redirect()->to('/cars')->with('error', 'Mobil tidak tersedia untuk disewa');
        }
        
        $data = [
            'title' => 'Rent a Car',
            'car' => $car
        ];
        
        return view('rentals/create', $data);
    }
    
    public function store()
    {
        $rules = [
            'car_id' => 'required|numeric',
            'start_date' => 'required|valid_date',
            'end_date' => 'required|valid_date',
            'payment_method' => 'required'
        ];
        
        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
        $carId = $this->request->getPost('car_id');
        $startDate = $this->request->getPost('start_date');
        $endDate = $this->request->getPost('end_date');
        $paymentMethod = $this->request->getPost('payment_method');
        
        // Calculate total days and price
        $start = new \DateTime($startDate);
        $end = new \DateTime($endDate);
        $days = $end->diff($start)->days + 1;
        
        $car = $this->carModel->find($carId);
        $totalPrice = $car['daily_rate'] * $days;
        
        // Create order
        $orderData = [
            'user_id' => session()->get('user_id'),
            'car_id' => $carId,
            'start_date' => $startDate,
            'end_date' => $endDate,
            'total_price' => $totalPrice,
            'status' => 'pending',
            'payment_status' => 'pending',
            'payment_method' => $paymentMethod
        ];
        
        $orderId = $this->orderModel->insert($orderData);
        
        if ($orderId) {
            // Update car status
            $this->carModel->update($carId, ['status' => 'pending']);
            
            // Handle payment proof upload if provided
            $paymentProof = $this->request->getFile('payment_proof');
            if ($paymentProof->isValid() && !$paymentProof->hasMoved()) {
                $proofName = $paymentProof->getRandomName();
                $paymentProof->move(ROOTPATH . 'public/uploads/payments', $proofName);
                
                // Create payment record
                $paymentData = [
                    'order_id' => $orderId,
                    'amount' => $totalPrice,
                    'payment_method' => $paymentMethod,
                    'payment_proof' => $proofName,
                    'status' => 'pending'
                ];
                
                $this->paymentModel->insert($paymentData);
            }
            
            return redirect()->to('/rentals')->with('success', 'Pesanan berhasil dibuat. Silakan lakukan pembayaran.');
        } else {
            return redirect()->back()->withInput()->with('error', 'Gagal membuat pesanan');
        }
    }
    
    public function show($id)
    {
        $order = $this->orderModel->getOrderWithDetails($id);
        
        if (!$order || $order['user_id'] != session()->get('user_id')) {
            return redirect()->to('/rentals')->with('error', 'Pesanan tidak ditemukan');
        }
        
        $payment = $this->paymentModel->where('order_id', $id)->first();
        
        $data = [
            'title' => 'Order Details',
            'order' => $order,
            'payment' => $payment
        ];
        
        return view('rentals/show', $data);
    }
    
    public function uploadPayment($id)
    {
        $order = $this->orderModel->find($id);
        
        if (!$order || $order['user_id'] != session()->get('user_id')) {
            return redirect()->to('/rentals')->with('error', 'Pesanan tidak ditemukan');
        }
        
        $paymentProof = $this->request->getFile('payment_proof');
        
        if ($paymentProof->isValid() && !$paymentProof->hasMoved()) {
            $proofName = $paymentProof->getRandomName();
            $paymentProof->move(ROOTPATH . 'public/uploads/payments', $proofName);
            
            // Update payment record
            $payment = $this->paymentModel->where('order_id', $id)->first();
            
            if ($payment) {
                $this->paymentModel->update($payment['id'], [
                    'payment_proof' => $proofName,
                    'status' => 'pending'
                ]);
            } else {
                $this->paymentModel->insert([
                    'order_id' => $id,
                    'amount' => $order['total_price'],
                    'payment_method' => $order['payment_method'],
                    'payment_proof' => $proofName,
                    'status' => 'pending'
                ]);
            }
            
            return redirect()->to('/rentals/' . $id)->with('success', 'Bukti pembayaran berhasil diunggah');
        } else {
            return redirect()->back()->with('error', 'Gagal mengunggah bukti pembayaran');
        }
    }
}

