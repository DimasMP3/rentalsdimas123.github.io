<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddStatusToReviews extends Migration
{
    public function up()
    {
        // Cek apakah tabel reviews sudah ada
        if ($this->db->tableExists('reviews')) {
            // Cek apakah kolom status sudah ada di tabel reviews
            if (!$this->db->fieldExists('status', 'reviews')) {
                // Tambahkan kolom status
                $this->forge->addColumn('reviews', [
                    'status' => [
                        'type'       => 'ENUM',
                        'constraint' => ['pending', 'approved', 'rejected'],
                        'default'    => 'pending',
                        'after'      => 'comment'
                    ]
                ]);
            }
        }
    }

    public function down()
    {
        // Cek apakah tabel reviews sudah ada
        if ($this->db->tableExists('reviews')) {
            // Cek apakah kolom status ada di tabel reviews
            if ($this->db->fieldExists('status', 'reviews')) {
                // Hapus kolom status
                $this->forge->dropColumn('reviews', 'status');
            }
        }
    }
} 