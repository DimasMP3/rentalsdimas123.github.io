<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddIsApprovedToReviews extends Migration
{
    public function up()
    {
        $fields = [
            'is_approved' => [
                'type'       => 'TINYINT',
                'constraint' => 1,
                'default'    => 0,
                'after'      => 'comment'
            ],
        ];

        $this->forge->addColumn('reviews', $fields);
    }

    public function down()
    {
        $this->forge->dropColumn('reviews', 'is_approved');
    }
} 