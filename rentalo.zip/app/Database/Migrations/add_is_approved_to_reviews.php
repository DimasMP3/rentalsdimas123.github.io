<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddIsApprovedToReviews extends Migration
{
    public function up()
    {
        $this->forge->addColumn('reviews', [
            'is_approved' => [
                'type'       => 'BOOLEAN',
                'default'    => 0,
                'after'      => 'comment'
            ],
        ]);
    }

    public function down()
    {
        $this->forge->dropColumn('reviews', 'is_approved');
    }
} 