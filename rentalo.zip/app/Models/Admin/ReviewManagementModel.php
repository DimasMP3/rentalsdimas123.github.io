<?php

namespace App\Models\Admin;

use CodeIgniter\Model;

class ReviewManagementModel extends Model
{
    protected $table = 'reviews';
    protected $primaryKey = 'id';
    
    public function getAllReviewsWithDetails($limit = null)
    {
        // Cek apakah kolom is_approved ada
        $fields = $this->db->getFieldData('reviews');
        $hasIsApprovedField = false;
        
        foreach ($fields as $field) {
            if ($field->name === 'is_approved') {
                $hasIsApprovedField = true;
                break;
            }
        }
        
        // Jika kolom belum ada, coba tambahkan
        if (!$hasIsApprovedField) {
            try {
                $this->db->query("ALTER TABLE reviews ADD COLUMN is_approved TINYINT(1) DEFAULT 0 AFTER comment");
                log_message('info', 'Kolom is_approved berhasil ditambahkan ke tabel reviews');
            } catch (\Exception $e) {
                log_message('error', 'Gagal menambahkan kolom is_approved: ' . $e->getMessage());
            }
        }
        
        $builder = $this->db->table('reviews')
            ->select('reviews.*, users.name as user_name, users.email as user_email, cars.brand, cars.model, cars.year')
            ->join('users', 'users.id = reviews.user_id')
            ->join('cars', 'cars.id = reviews.car_id')
            ->orderBy('reviews.created_at', 'DESC');
            
        if ($limit !== null) {
            $builder->limit($limit);
        }
        
        return $builder->get()->getResultArray();
    }
    
    public function getReviewDetails($id)
    {
        // Cek apakah kolom is_approved ada
        $fields = $this->db->getFieldData('reviews');
        $hasIsApprovedField = false;
        
        foreach ($fields as $field) {
            if ($field->name === 'is_approved') {
                $hasIsApprovedField = true;
                break;
            }
        }
        
        // Jika kolom belum ada, coba tambahkan
        if (!$hasIsApprovedField) {
            try {
                $this->db->query("ALTER TABLE reviews ADD COLUMN is_approved TINYINT(1) DEFAULT 0 AFTER comment");
                log_message('info', 'Kolom is_approved berhasil ditambahkan ke tabel reviews');
            } catch (\Exception $e) {
                log_message('error', 'Gagal menambahkan kolom is_approved: ' . $e->getMessage());
            }
        }
        
        return $this->db->table('reviews')
            ->select('reviews.*, users.name as user_name, users.email as user_email, users.phone as user_phone, cars.brand, cars.model, cars.year, cars.image')
            ->join('users', 'users.id = reviews.user_id')
            ->join('cars', 'cars.id = reviews.car_id')
            ->where('reviews.id', $id)
            ->get()
            ->getRowArray();
    }
    
    public function getPendingReviewsCount()
    {
        // Cek apakah kolom is_approved ada
        $fields = $this->db->getFieldData('reviews');
        $hasIsApprovedField = false;
        
        foreach ($fields as $field) {
            if ($field->name === 'is_approved') {
                $hasIsApprovedField = true;
                break;
            }
        }
        
        if ($hasIsApprovedField) {
            return $this->db->table('reviews')
                ->where('is_approved', 0)
                ->countAllResults();
        } else {
            // Jika kolom belum ada, kembalikan 0
            return 0;
        }
    }
    
    public function approveReview($id)
    {
        // Cek apakah kolom is_approved ada
        $fields = $this->db->getFieldData('reviews');
        $hasIsApprovedField = false;
        
        foreach ($fields as $field) {
            if ($field->name === 'is_approved') {
                $hasIsApprovedField = true;
                break;
            }
        }
        
        if ($hasIsApprovedField) {
            return $this->db->table('reviews')
                ->where('id', $id)
                ->update(['is_approved' => 1]);
        } else {
            // Jika kolom belum ada, tambahkan kolom terlebih dahulu
            try {
                $this->db->query("ALTER TABLE reviews ADD COLUMN is_approved TINYINT(1) DEFAULT 0 AFTER comment");
                
                // Sekarang update record
                return $this->db->table('reviews')
                    ->where('id', $id)
                    ->update(['is_approved' => 1]);
            } catch (\Exception $e) {
                log_message('error', 'Gagal menambahkan kolom is_approved: ' . $e->getMessage());
                return false;
            }
        }
    }
    
    public function deleteReview($id)
    {
        return $this->db->table('reviews')
            ->where('id', $id)
            ->delete();
    }
} 