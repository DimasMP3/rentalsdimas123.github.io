<?php

namespace App\Models;

use CodeIgniter\Model;

class ReviewModel extends Model
{
    protected $table = 'reviews';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'user_id', 'car_id', 'rating', 'comment'
    ];
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';
    
    // Get reviews with user information
    public function getReviewsWithUser($carId)
    {
        return $this->db->table('reviews')
            ->select('reviews.*, users.name as user_name')
            ->join('users', 'users.id = reviews.user_id')
            ->where('reviews.car_id', $carId)
            ->orderBy('reviews.created_at', 'DESC')
            ->get()
            ->getResultArray();
    }
    
    // Check if user has already reviewed a car
    public function hasUserReviewed($userId, $carId)
    {
        return $this->where('user_id', $userId)
            ->where('car_id', $carId)
            ->countAllResults() > 0;
    }
}

