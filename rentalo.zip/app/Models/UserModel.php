<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table = 'users';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'name', 'email', 'password', 'phone', 'address', 
        'license_number', 'role'
    ];
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';
    
    // Join with rentals to get user's rental history
    public function getRentalHistory($userId)
    {
        return $this->db->table('rentals')
            ->join('cars', 'cars.id = rentals.car_id')
            ->where('rentals.user_id', $userId)
            ->get()
            ->getResultArray();
    }
}

