<?= $this->extend('layouts/admin') ?>
<?= $this->section('content') ?>
<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>Order Details</h1>
        <a href="<?= site_url('admin/orders') ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-2"></i> Back to Orders
        </a>
    </div>
    
    <div class="card">
        <div class="card-body">
            <?php if (session()->has('success')): ?>
            <div class="alert alert-success">
                <?= session('success') ?>
            </div>
            <?php endif; ?>
            
            <?php if (session()->has('error')): ?>
            <div class="alert alert-danger">
                <?= session('error') ?>
            </div>
            <?php endif; ?>
            
            <div class="row">
                <div class="col-md-6">
                    <h5 class="mb-3">Order Information</h5>
                    <table class="table">
                        <tr>
                            <th>Order ID</th>
                            <td><?= $order['id'] ?></td>
                        </tr>
                        <tr>
                            <th>Status</th>
                            <td>
                                <span class="badge bg-<?= $order['status'] == 'pending' ? 'warning' : ($order['status'] == 'approved' ? 'success' : ($order['status'] == 'completed' ? 'info' : 'danger')) ?>">
                                    <?= ucfirst($order['status']) ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <th>Start Date</th>
                            <td><?= date('d M Y', strtotime($order['start_date'])) ?></td>
                        </tr>
                        <tr>
                            <th>End Date</th>
                            <td><?= date('d M Y', strtotime($order['end_date'])) ?></td>
                        </tr>
                        <tr>
                            <th>Total Price</th>
                            <td>$<?= number_format($order['total_price'], 2) ?></td>
                        </tr>
                    </table>
                </div>
                
                <div class="col-md-6">
                    <h5 class="mb-3">Customer Information</h5>
                    <table class="table">
                        <tr>
                            <th>Name</th>
                            <td><?= $order['user_name'] ?></td>
                        </tr>
                        <tr>
                            <th>Email</th>
                            <td><?= $order['user_email'] ?></td>
                        </tr>
                    </table>
                    
                    <h5 class="mb-3 mt-4">Car Information</h5>
                    <table class="table">
                        <tr>
                            <th>Car</th>
                            <td><?= $order['brand'] . ' ' . $order['model'] ?></td>
                        </tr>
                        <tr>
                            <th>Year</th>
                            <td><?= $order['year'] ?></td>
                        </tr>
                        <tr>
                            <th>License Plate</th>
                            <td><?= $order['license_plate'] ?></td>
                        </tr>
                        <tr>
                            <th>Daily Rate</th>
                            <td>Rp <?= number_format($order['daily_rate'], 0, ',', '.') ?></td>
                        </tr>
                    </table>
                    
                    <?php if(!empty($order['image'])): ?>
                    <div class="mt-3">
                        <img src="<?= base_url('uploads/cars/' . $order['image']) ?>" class="img-fluid rounded" style="max-height: 200px;" alt="<?= $order['brand'] . ' ' . $order['model'] ?>">
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <?php if ($order['status'] == 'pending'): ?>
            <div class="mt-4">
                <form action="<?= site_url('admin/orders/update-status/' . $order['id']) ?>" method="post">
                    <?= csrf_field() ?>
                    <input type="hidden" name="status" value="approved">
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-check me-2"></i> Approve Order
                    </button>
                </form>
            </div>
            <?php endif; ?>
            
            <?php if ($order['status'] == 'approved'): ?>
            <div class="mt-4">
                <form action="<?= site_url('admin/orders/update-status/' . $order['id']) ?>" method="post">
                    <?= csrf_field() ?>
                    <input type="hidden" name="status" value="completed">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-flag-checkered me-2"></i> Mark as Completed
                    </button>
                </form>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?= $this->endSection() ?> 