<?= $this->extend('admin/layout/main') ?>

<?= $this->section('content') ?>
<div class="container-fluid">
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Detail Ulasan</h1>
        <a href="<?= site_url('admin/reviews') ?>" class="d-none d-sm-inline-block btn btn-sm btn-secondary shadow-sm">
            <i class="fas fa-arrow-left fa-sm text-white-50"></i> Kembali
        </a>
    </div>
    
    <!-- Notification Messages -->
    <?php if (session()->getFlashdata('success')): ?>
    <div class="alert alert-success">
        <?= session()->getFlashdata('success') ?>
    </div>
    <?php endif; ?>
    
    <?php if (session()->getFlashdata('error')): ?>
    <div class="alert alert-danger">
        <?= session()->getFlashdata('error') ?>
    </div>
    <?php endif; ?>
    
    <!-- Content Row -->
    <div class="row">
        <div class="col-lg-4">
            <!-- Car Image -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Mobil</h6>
                </div>
                <div class="card-body text-center">
                    <img src="<?= base_url('uploads/cars/' . $review['image']) ?>" alt="<?= $review['brand'] . ' ' . $review['model'] ?>" class="img-fluid mb-3" style="max-height: 200px; object-fit: cover;">
                    <h5><?= $review['brand'] . ' ' . $review['model'] ?></h5>
                    <p class="text-muted"><?= $review['year'] ?></p>
                    <a href="<?= site_url('admin/cars/detail/' . $review['car_id']) ?>" class="btn btn-primary btn-sm">
                        <i class="fas fa-info-circle"></i> Lihat Detail Mobil
                    </a>
                </div>
            </div>
            
            <!-- Customer Info -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Informasi Pelanggan</h6>
                </div>
                <div class="card-body">
                    <div class="mb-2">
                        <strong>Nama:</strong>
                        <p><?= $review['user_name'] ?></p>
                    </div>
                    <div class="mb-2">
                        <strong>Email:</strong>
                        <p><?= $review['user_email'] ?></p>
                    </div>
                    <?php if (isset($review['user_phone'])): ?>
                    <div class="mb-2">
                        <strong>Telepon:</strong>
                        <p><?= $review['user_phone'] ?></p>
                    </div>
                    <?php endif; ?>
                    <a href="<?= site_url('admin/users/detail/' . $review['user_id']) ?>" class="btn btn-primary btn-sm">
                        <i class="fas fa-user"></i> Lihat Profil Pelanggan
                    </a>
                </div>
            </div>
        </div>
        
        <div class="col-lg-8">
            <!-- Review Details -->
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Detail Ulasan</h6>
                    <div>
                        <?php if (isset($review['is_approved'])): ?>
                            <?php if ($review['is_approved'] == 1): ?>
                                <span class="badge bg-success">Disetujui</span>
                            <?php else: ?>
                                <span class="badge bg-warning">Menunggu Persetujuan</span>
                            <?php endif; ?>
                        <?php else: ?>
                            <span class="badge bg-warning">Menunggu Persetujuan</span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <h5>Rating</h5>
                        <div class="mb-2">
                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                <?php if ($i <= $review['rating']): ?>
                                    <i class="fas fa-star fa-2x text-warning"></i>
                                <?php else: ?>
                                    <i class="far fa-star fa-2x text-muted"></i>
                                <?php endif; ?>
                            <?php endfor; ?>
                        </div>
                        <p class="text-muted"><?= $review['rating'] ?> dari 5 bintang</p>
                    </div>
                    
                    <div class="mb-3">
                        <h5>Ulasan</h5>
                        <div class="border p-3 rounded bg-light">
                            <p><?= nl2br($review['comment']) ?></p>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <h5>Tanggal Ulasan</h5>
                        <p><?= date('d F Y H:i', strtotime($review['created_at'])) ?></p>
                    </div>
                    
                    <div class="d-flex mt-4">
                        <?php if (!isset($review['is_approved']) || $review['is_approved'] == 0): ?>
                        <a href="<?= site_url('admin/reviews/approve/' . $review['id']) ?>" class="btn btn-success mr-2" onclick="return confirm('Apakah Anda yakin ingin menyetujui ulasan ini?');">
                            <i class="fas fa-check"></i> Setujui Ulasan
                        </a>
                        <?php endif; ?>
                        <a href="<?= site_url('admin/reviews/delete/' . $review['id']) ?>" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus ulasan ini?');">
                            <i class="fas fa-trash"></i> Hapus Ulasan
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('styles') ?>
<style>
    .badge {
        padding: 0.5em 0.75em;
    }
    
    .bg-success {
        background-color: #28a745!important;
        color: white;
    }
    
    .bg-warning {
        background-color: #ffc107!important;
        color: #212529;
    }
    
    .mr-2 {
        margin-right: 0.5rem;
    }
</style>
<?= $this->endSection() ?> 