<?= $this->extend('admin/layout/main') ?>

<?= $this->section('content') ?>
<div class="container-fluid">
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Manajemen Ulasan</h1>
    </div>
    
    <!-- Notification Messages -->
    <?php if (session()->getFlashdata('success')): ?>
    <div class="alert alert-success">
        <?= session()->getFlashdata('success') ?>
    </div>
    <?php endif; ?>
    
    <?php if (session()->getFlashdata('error')): ?>
    <div class="alert alert-danger">
        <?= session()->getFlashdata('error') ?>
    </div>
    <?php endif; ?>
    
    <!-- Content Row -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Daftar Ulasan Pelanggan</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Pelanggan</th>
                            <th>Mobil</th>
                            <th>Rating</th>
                            <th>Ulasan</th>
                            <th>Tanggal</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; ?>
                        <?php foreach ($reviews as $review): ?>
                        <tr>
                            <td><?= $i++ ?></td>
                            <td><?= $review['user_name'] ?></td>
                            <td><?= $review['brand'] . ' ' . $review['model'] . ' (' . $review['year'] . ')' ?></td>
                            <td>
                                <?php for ($j = 1; $j <= 5; $j++): ?>
                                    <?php if ($j <= $review['rating']): ?>
                                        <i class="fas fa-star text-warning"></i>
                                    <?php else: ?>
                                        <i class="far fa-star text-muted"></i>
                                    <?php endif; ?>
                                <?php endfor; ?>
                            </td>
                            <td><?= strlen($review['comment']) > 100 ? substr($review['comment'], 0, 100) . '...' : $review['comment'] ?></td>
                            <td><?= date('d/m/Y H:i', strtotime($review['created_at'])) ?></td>
                            <td>
                                <?php if (isset($review['is_approved'])): ?>
                                    <?php if ($review['is_approved'] == 1): ?>
                                        <span class="badge bg-success">Disetujui</span>
                                    <?php else: ?>
                                        <span class="badge bg-warning">Menunggu</span>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="badge bg-warning">Menunggu</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?= site_url('admin/reviews/detail/' . $review['id']) ?>" class="btn btn-info btn-sm mb-1">
                                    <i class="fas fa-eye"></i> Detail
                                </a>
                                <?php if (!isset($review['is_approved']) || $review['is_approved'] == 0): ?>
                                <a href="<?= site_url('admin/reviews/approve/' . $review['id']) ?>" class="btn btn-success btn-sm mb-1" onclick="return confirm('Apakah Anda yakin ingin menyetujui ulasan ini?');">
                                    <i class="fas fa-check"></i> Setujui
                                </a>
                                <?php endif; ?>
                                <a href="<?= site_url('admin/reviews/delete/' . $review['id']) ?>" class="btn btn-danger btn-sm mb-1" onclick="return confirm('Apakah Anda yakin ingin menghapus ulasan ini?');">
                                    <i class="fas fa-trash"></i> Hapus
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('styles') ?>
<style>
    .badge {
        padding: 0.5em 0.75em;
    }
</style>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
    $(document).ready(function() {
        $('#dataTable').DataTable();
    });
</script>
<?= $this->endSection() ?> 