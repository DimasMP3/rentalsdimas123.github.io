<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container py-5">
    <div class="cars-header mb-4">
        <h1 class="cars-title"><?= isset($current_category) ? 'Mobil ' . $current_category['name'] : 'Mobil Tersedia' ?></h1>
        <p class="cars-subtitle">Pilih dan sewa mobil yang sesuai dengan kebutuhan Anda</p>
    </div>
    
    <div class="row">
        <div class="col-md-3">
            <div class="filter-card mb-4">
                <div class="filter-header">
                    <h5 class="mb-0">Filter Pencarian</h5>
                </div>
                <div class="filter-body">
                    <form action="<?= site_url('cars') ?>" method="get">
                        <div class="mb-3">
                            <label for="category" class="filter-label">Kategori</label>
                            <select name="category" id="category" class="form-select">
                                <option value="">Semua Kategori</option>
                                <?php foreach ($categories as $category): ?>
                                <option value="<?= $category['id'] ?>" <?= isset($_GET['category']) && $_GET['category'] == $category['id'] ? 'selected' : '' ?>>
                                    <?= $category['name'] ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="min_price" class="filter-label">Harga Minimum</label>
                            <input type="number" name="min_price" id="min_price" class="form-control" value="<?= isset($_GET['min_price']) ? $_GET['min_price'] : '' ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label for="max_price" class="filter-label">Harga Maksimum</label>
                            <input type="number" name="max_price" id="max_price" class="form-control" value="<?= isset($_GET['max_price']) ? $_GET['max_price'] : '' ?>">
                        </div>
                        
                        <button type="submit" class="filter-button">Terapkan Filter</button>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-md-9">
            <?php if (empty($cars)): ?>
            <div class="alert alert-info">Tidak ada mobil yang sesuai kriteria pencarian Anda.</div>
            <?php else: ?>
            <div class="cars-grid">
                <?php foreach ($cars as $car): ?>
                <div class="car-card-wrapper">
                    <div class="car-card">
                        <div class="availability-tag">Tersedia</div>
                        <div class="car-image-container">
                            <img src="<?= base_url('uploads/cars/' . $car['image']) ?>" class="car-image" alt="<?= $car['brand'] . ' ' . $car['model'] ?>">
                        </div>
                        <div class="car-details">
                            <h3 class="car-name"><?= $car['brand'] . ' ' . $car['model'] ?></h3>
                            
                            <div class="price-section">
                                <div class="price-row">
                                    <div class="price-category">
                                        <div class="price-label">12 jam / dalam kota</div>
                                    </div>
                                    <div class="price-amount">
                                        Rp <?= number_format($car['daily_rate'] * 0.5, 0, ',', '.') ?> - Rp 
                                        <?= number_format($car['daily_rate'] * 0.75, 0, ',', '.') ?>
                                    </div>
                                </div>
                                <div class="price-row">
                                    <div class="price-category">
                                        <div class="price-label">Harian + Supir</div>
                                    </div>
                                    <div class="price-amount">
                                        Rp <?= number_format($car['daily_rate'] * 0.75, 0, ',', '.') ?> - Rp 
                                        <?= number_format($car['daily_rate'], 0, ',', '.') ?>
                                    </div>
                                </div>
                                <div class="price-row monthly">
                                    <div class="price-category">
                                        <div class="price-label">Monthly</div>
                                    </div>
                                    <div class="price-amount monthly-price">
                                        Rp <?= number_format($car['daily_rate'] * 30 * 0.8, 0, ',', '.') ?>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="car-actions">
                                <a href="<?= site_url('cars/' . $car['id']) ?>" class="detail-button">
                                    <i class="fas fa-info-circle"></i> Detail
                                </a>
                                <a href="https://wa.me/083896297994?text=Saya%20tertarik%20untuk%20menyewa%20<?= urlencode($car['brand'] . ' ' . $car['model']) ?>" class="book-button">
                                    <i class="fab fa-whatsapp"></i> Pesan
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
    .cars-header {
        text-align: center;
        margin-bottom: 40px;
    }
    
    .cars-title {
        font-weight: 700;
        color: var(--text-color);
        margin-bottom: 10px;
    }
    
    .cars-subtitle {
        color: var(--gray-color);
        font-size: 1.1rem;
    }
    
    .filter-card {
        background-color: white;
        border-radius: 12px;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        overflow: hidden;
    }
    
    .filter-header {
        background-color: var(--light-gray);
        padding: 15px 20px;
        border-bottom: 1px solid rgba(0, 0, 0, 0.05);
    }
    
    .filter-body {
        padding: 20px;
    }
    
    .filter-label {
        font-weight: 600;
        color: var(--text-color);
        margin-bottom: 8px;
        font-size: 0.9rem;
    }
    
    .filter-button {
        background: linear-gradient(135deg, var(--gradient-start) 0%, var(--gradient-end) 100%);
        color: white;
        border: none;
        padding: 10px 0;
        border-radius: 8px;
        font-weight: 600;
        width: 100%;
        transition: all 0.3s ease;
        cursor: pointer;
    }
    
    .filter-button:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(67, 97, 238, 0.3);
    }
    
    .cars-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
        gap: 25px;
    }
    
    .car-card-wrapper {
        width: 100%;
    }
    
    .car-card {
        background-color: white;
        border-radius: 12px;
        overflow: hidden;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        transition: all 0.3s ease;
        height: 100%;
        position: relative;
        display: flex;
        flex-direction: column;
    }
    
    .car-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.08);
    }
    
    .availability-tag {
        position: absolute;
        top: 15px;
        left: 15px;
        background: linear-gradient(135deg, #4ade80 0%, #22c55e 100%);
        color: white;
        padding: 5px 12px;
        border-radius: 50px;
        font-size: 0.8rem;
        font-weight: 600;
        z-index: 1;
        box-shadow: 0 3px 8px rgba(34, 197, 94, 0.3);
    }
    
    .car-image-container {
        height: 200px;
        overflow: hidden;
        position: relative;
        border-radius: 12px 12px 0 0;
    }
    
    .car-image {
        width: 100%;
        height: 100%;
        object-fit: cover;
        object-position: center;
        transition: transform 0.5s ease;
    }
    
    .car-card:hover .car-image {
        transform: scale(1.08);
    }
    
    .car-details {
        padding: 20px;
        display: flex;
        flex-direction: column;
        flex-grow: 1;
    }
    
    .car-name {
        font-size: 1.25rem;
        font-weight: 700;
        margin-bottom: 15px;
        color: var(--text-color);
        text-align: center;
    }
    
    .price-section {
        margin-bottom: 20px;
        flex-grow: 1;
    }
    
    .price-row {
        display: grid;
        grid-template-columns: 0.9fr 1.1fr;
        padding: 8px 0;
        border-bottom: 1px dashed rgba(0, 0, 0, 0.06);
        align-items: center;
    }
    
    .price-row.monthly {
        border-bottom: none;
    }
    
    .price-category {
        color: var(--gray-color);
    }
    
    .price-label {
        font-size: 0.85rem;
    }
    
    .price-amount {
        font-weight: 600;
        font-size: 0.9rem;
        text-align: right;
        white-space: nowrap;
        color: #333;
    }
    
    .price-amount.monthly-price {
        color: #4361ee;
        font-weight: 700;
        font-size: 1rem;
    }
    
    .car-actions {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 10px;
    }
    
    .detail-button {
        display: flex;
        align-items: center;
        justify-content: center;
        background: linear-gradient(135deg, var(--gradient-start) 0%, var(--gradient-end) 100%);
        color: white;
        padding: 8px;
        border-radius: 8px;
        text-decoration: none;
        font-weight: 600;
        transition: all 0.3s ease;
        font-size: 0.9rem;
    }
    
    .detail-button i {
        margin-right: 5px;
    }
    
    .detail-button:hover {
        background: linear-gradient(135deg, var(--gradient-end) 0%, var(--gradient-start) 100%);
        color: white;
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(67, 97, 238, 0.25);
    }
    
    .book-button {
        display: flex;
        align-items: center;
        justify-content: center;
        background: linear-gradient(135deg, #25D366 0%, #128C7E 100%);
        color: white;
        padding: 8px;
        border-radius: 8px;
        text-decoration: none;
        font-weight: 600;
        transition: all 0.3s ease;
        font-size: 0.9rem;
    }
    
    .book-button i {
        margin-right: 5px;
    }
    
    .book-button:hover {
        background: linear-gradient(135deg, #128C7E 0%, #25D366 100%);
        color: white;
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(37, 211, 102, 0.25);
    }
    
    @media (max-width: 991px) {
        .cars-grid {
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
        }
    }
    
    @media (max-width: 767px) {
        .cars-grid {
            grid-template-columns: repeat(auto-fill, minmax(100%, 1fr));
        }
    }
</style>
<?= $this->endSection() ?>
