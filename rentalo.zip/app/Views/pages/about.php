<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container py-5">
    <h1 class="mb-4">About Us</h1>
    
    <div class="row">
        <div class="col-md-6 mb-4">
            <img src="<?= base_url('assets/images/about-us.jpg') ?>" alt="About CarRent" class="img-fluid rounded">
        </div>
        <div class="col-md-6 mb-4">
            <h2>Our Story</h2>
            <p>CarRent was founded in 2010 with a simple mission: to provide high-quality car rental services at affordable prices. What started as a small fleet of just 5 cars has now grown into a comprehensive rental service with over 100 vehicles of various makes and models.</p>
            <p>Our founder, John Smith, recognized the need for a reliable car rental service that prioritized customer satisfaction above all else. This vision continues to guide our operations today.</p>
            <p>Over the years, we have served thousands of satisfied customers, from tourists exploring new destinations to locals in need of temporary transportation solutions.</p>
        </div>
    </div>
    
    <div class="row mb-5">
        <div class="col-12">
            <h2 class="text-center mb-4">Our Mission & Values</h2>
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-body text-center">
                            <i class="fas fa-handshake fa-3x text-primary mb-3"></i>
                            <h4>Customer First</h4>
                            <p>We prioritize customer satisfaction in every aspect of our service, ensuring a seamless rental experience from start to finish.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-body text-center">
                            <i class="fas fa-shield-alt fa-3x text-primary mb-3"></i>
                            <h4>Safety & Reliability</h4>
                            <p>All our vehicles undergo rigorous maintenance checks to ensure they are safe and reliable for our customers.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-body text-center">
                            <i class="fas fa-leaf fa-3x text-primary mb-3"></i>
                            <h4>Environmental Responsibility</h4>
                            <p>We are committed to reducing our environmental footprint by maintaining fuel-efficient vehicles and adopting sustainable practices.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row mb-5">
        <div class="col-12">
            <h2 class="text-center mb-4">Our Team</h2>
            <div class="row">
                <div class="col-md-3 mb-4">
                    <div class="card text-center">
                        <img src="<?= base_url('assets/images/team-1.jpg') ?>" class="card-img-top" alt="Team Member">
                        <div class="card-body">
                            <h5 class="card-title">John Smith</h5>
                            <p class="card-text text-muted">Founder & CEO</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-4">
                    <div class="card text-center">
                        <img src="<?= base_url('assets/images/team-2.jpg') ?>" class="card-img-top" alt="Team Member">
                        <div class="card-body">
                            <h5 class="card-title">Sarah Johnson</h5>
                            <p class="card-text text-muted">Operations Manager</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-4">
                    <div class="card text-center">
                        <img src="<?= base_url('assets/images/team-3.jpg') ?>" class="card-img-top" alt="Team Member">
                        <div class="card-body">
                            <h5 class="card-title">Michael Brown</h5>
                            <p class="card-text text-muted">Fleet Manager</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-4">
                    <div class="card text-center">
                        <img src="<?= base_url('assets/images/team-4.jpg') ?>" class="card-img-top" alt="Team Member">
                        <div class="card-body">
                            <h5 class="card-title">Emily Davis</h5>
                            <p class="card-text text-muted">Customer Service Lead</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="col-12">
            <h2 class="text-center mb-4">Why Choose Us</h2>
            <div class="row">
                <div class="col-md-6 mb-4">
                    <div class="d-flex">
                        <div class="flex-shrink-0">
                            <i class="fas fa-check-circle text-primary fa-2x me-3"></i>
                        </div>
                        <div>
                            <h5>Wide Selection of Vehicles</h5>
                            <p>From economy cars to luxury vehicles, we have a diverse fleet to meet your specific needs and preferences.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 mb-4">
                    <div class="d-flex">
                        <div class="flex-shrink-0">
                            <i class="fas fa-check-circle text-primary fa-2x me-3"></i>
                        </div>
                        <div>
                            <h5>Competitive Pricing</h5>
                            <p>We offer the best rates in the market with no hidden fees or charges, ensuring transparency in our pricing.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 mb-4">
                    <div class="d-flex">
                        <div class="flex-shrink-0">
                            <i class="fas fa-check-circle text-primary fa-2x me-3"></i>
                        </div>
                        <div>
                            <h5>Flexible Rental Options</h5>
                            <p>Whether you need a car for a day, a week, or a month, we have flexible rental options to accommodate your schedule.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 mb-4">
                    <div class="d-flex">
                        <div class="flex-shrink-0">
                            <i class="fas fa-check-circle text-primary fa-2x me-3"></i>
                        </div>
                        <div>
                            <h5>24/7 Customer Support</h5>
                            <p>Our dedicated customer service team is available around the clock to assist you with any queries or concerns.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
