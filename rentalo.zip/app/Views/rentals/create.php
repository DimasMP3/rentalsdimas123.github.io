<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">Sewa Mobil</h4>
                </div>
                <div class="card-body">
                    <?php if (session()->has('errors')): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php foreach (session('errors') as $error): ?>
                            <li><?= $error ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                    
                    <div class="row mb-4">
                        <div class="col-md-4">
                            <img src="<?= base_url('uploads/cars/' . $car['image']) ?>" class="img-fluid rounded" alt="<?= $car['brand'] . ' ' . $car['model'] ?>">
                        </div>
                        <div class="col-md-8">
                            <h3><?= $car['brand'] . ' ' . $car['model'] ?></h3>
                            <p class="text-muted"><?= $car['year'] ?> • Plat: <?= $car['license_plate'] ?></p>
                            <h4 class="text-primary">Rp <?= number_format($car['daily_rate'], 0, ',', '.') ?> / hari</h4>
                            <p><?= $car['description'] ?></p>
                        </div>
                    </div>
                    
                    <form action="<?= site_url('rentals/store') ?>" method="post" enctype="multipart/form-data">
                        <?= csrf_field() ?>
                        <input type="hidden" name="car_id" value="<?= $car['id'] ?>">
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="start_date" class="form-label">Tanggal Mulai</label>
                                <input type="date" name="start_date" id="start_date" class="form-control" min="<?= date('Y-m-d') ?>" required>
                            </div>
                            <div class="col-md-6">
                                <label for="end_date" class="form-label">Tanggal Selesai</label>
                                <input type="date" name="end_date" id="end_date" class="form-control" min="<?= date('Y-m-d', strtotime('+1 day')) ?>" required>
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="payment_method" class="form-label">Metode Pembayaran</label>
                                <select name="payment_method" id="payment_method" class="form-select" required>
                                    <option value="">Pilih Metode Pembayaran</option>
                                    <option value="bank_transfer">Transfer Bank</option>
                                    <option value="credit_card">Kartu Kredit</option>
                                    <option value="debit_card">Kartu Debit</option>
                                    <option value="paypal">PayPal</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label for="payment_proof" class="form-label">Bukti Pembayaran (Opsional)</label>
                                <input type="file" name="payment_proof" id="payment_proof" class="form-control" accept="image/*">
                                <div class="form-text">Anda dapat mengupload bukti pembayaran sekarang atau nanti.</div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="notes" class="form-label">Catatan</label>
                            <textarea name="notes" id="notes" class="form-control" rows="3"></textarea>
                        </div>
                        
                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary">Pesan Sekarang</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const startDateInput = document.getElementById('start_date');
    const endDateInput = document.getElementById('end_date');
    
    startDateInput.addEventListener('change', function() {
        // Set min date for end date to be at least start_date + 1
        const startDate = new Date(this.value);
        startDate.setDate(startDate.getDate() + 1);
        const minEndDate = startDate.toISOString().split('T')[0];
        endDateInput.min = minEndDate;
        
        // If current end date is less than new min, update it
        if (endDateInput.value && endDateInput.value < minEndDate) {
            endDateInput.value = minEndDate;
        }
    });
});
</script>
<?= $this->endSection() ?>
