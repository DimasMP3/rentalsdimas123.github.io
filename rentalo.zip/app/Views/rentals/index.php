<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container py-5">
    <h1 class="mb-4">Pesanan Saya</h1>
    
    <?php if (session()->has('success')): ?>
    <div class="alert alert-success">
        <?= session('success') ?>
    </div>
    <?php endif; ?>
    
    <?php if (session()->has('error')): ?>
    <div class="alert alert-danger">
        <?= session('error') ?>
    </div>
    <?php endif; ?>
    
    <?php if (empty($orders)): ?>
    <div class="alert alert-info">
        Anda belum memiliki pesanan. <a href="<?= site_url('cars') ?>" class="alert-link">Lihat daftar mobil</a> untuk mulai menyewa.
    </div>
    <?php else: ?>
    <div class="row">
        <?php foreach ($orders as $order): ?>
        <div class="col-md-6 mb-4">
            <div class="card shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="card-title mb-0"><?= $order['brand'] . ' ' . $order['model'] ?></h5>
                        <span class="badge bg-<?= $order['status'] == 'pending' ? 'warning' : ($order['status'] == 'approved' ? 'success' : ($order['status'] == 'completed' ? 'info' : 'danger')) ?>">
                            <?= ucfirst($order['status']) ?>
                        </span>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <p class="mb-1"><strong>Mulai:</strong></p>
                            <p><?= date('d M Y', strtotime($order['start_date'])) ?></p>
                        </div>
                        <div class="col-md-6">
                            <p class="mb-1"><strong>Selesai:</strong></p>
                            <p><?= date('d M Y', strtotime($order['end_date'])) ?></p>
                        </div>
                    </div>
                    
                    <p><strong>Total Harga:</strong> Rp <?= number_format($order['total_price'], 0, ',', '.') ?></p>
                    
                    <p><strong>Status Pembayaran:</strong> 
                        <span class="badge bg-<?= $order['payment_status'] == 'paid' ? 'success' : ($order['payment_status'] == 'pending' ? 'warning' : 'danger') ?>">
                            <?= $order['payment_status'] == 'paid' ? 'Lunas' : ($order['payment_status'] == 'pending' ? 'Menunggu Pembayaran' : 'Gagal') ?>
                        </span>
                    </p>
                    
                    <div class="d-grid mt-3">
                        <a href="<?= site_url('rentals/' . $order['id']) ?>" class="btn btn-primary">Lihat Detail</a>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>
<?= $this->endSection() ?>
