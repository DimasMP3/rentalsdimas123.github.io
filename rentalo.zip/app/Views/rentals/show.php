<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1>Detail Pesanan</h1>
                <a href="<?= site_url('rentals') ?>" class="btn btn-secondary">
                    <i class="fas fa-arrow-left me-2"></i> Kembali ke Pesanan
                </a>
            </div>
            
            <?php if (session()->has('success')): ?>
            <div class="alert alert-success">
                <?= session('success') ?>
            </div>
            <?php endif; ?>
            
            <?php if (session()->has('error')): ?>
            <div class="alert alert-danger">
                <?= session('error') ?>
            </div>
            <?php endif; ?>
            
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Informasi Pesanan</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong>ID Pesanan:</strong> #<?= $order['id'] ?></p>
                            <p><strong>Status:</strong> 
                                <span class="badge bg-<?= $order['status'] == 'pending' ? 'warning' : ($order['status'] == 'approved' ? 'success' : ($order['status'] == 'completed' ? 'info' : 'danger')) ?>">
                                    <?= ucfirst($order['status']) ?>
                                </span>
                            </p>
                            <p><strong>Tanggal Mulai:</strong> <?= date('d M Y', strtotime($order['start_date'])) ?></p>
                            <p><strong>Tanggal Selesai:</strong> <?= date('d M Y', strtotime($order['end_date'])) ?></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Total Harga:</strong> Rp <?= number_format($order['total_price'], 0, ',', '.') ?></p>
                            <p><strong>Metode Pembayaran:</strong> <?= ucfirst(str_replace('_', ' ', $order['payment_method'])) ?></p>
                            <p><strong>Status Pembayaran:</strong> 
                                <span class="badge bg-<?= $order['payment_status'] == 'paid' ? 'success' : ($order['payment_status'] == 'pending' ? 'warning' : 'danger') ?>">
                                    <?= $order['payment_status'] == 'paid' ? 'Lunas' : ($order['payment_status'] == 'pending' ? 'Menunggu Pembayaran' : 'Gagal') ?>
                                </span>
                            </p>
                            <?php if (!empty($order['notes'])): ?>
                            <p><strong>Catatan:</strong> <?= $order['notes'] ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Informasi Mobil</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-4">
                            <?php if(!empty($order['image'])): ?>
                            <img src="<?= base_url('uploads/cars/' . $order['image']) ?>" class="img-fluid rounded" alt="<?= $order['brand'] . ' ' . $order['model'] ?>">
                            <?php else: ?>
                            <div class="bg-light text-center py-5 rounded">
                                <i class="fas fa-car fa-4x text-secondary"></i>
                                <p class="mt-2 text-muted">No image available</p>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-8">
                            <h4><?= $order['brand'] . ' ' . $order['model'] ?></h4>
                            <p class="text-muted"><?= $order['year'] ?> • Plat: <?= $order['license_plate'] ?></p>
                            <p><strong>Harga Sewa:</strong> Rp <?= number_format($order['daily_rate'], 0, ',', '.') ?> / hari</p>
                            <p><?= $order['description'] ?></p>
                        </div>
                    </div>
                </div>
            </div>
            
            <?php if ($order['payment_status'] == 'pending'): ?>
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Upload Bukti Pembayaran</h5>
                </div>
                <div class="card-body">
                    <?php if (isset($payment) && !empty($payment['payment_proof'])): ?>
                    <div class="mb-3">
                        <p><strong>Bukti Pembayaran Saat Ini:</strong></p>
                        <img src="<?= base_url('uploads/payments/' . $payment['payment_proof']) ?>" class="img-fluid rounded mb-3" style="max-height: 300px;" alt="Bukti Pembayaran">
                        <p>Bukti pembayaran sedang ditinjau oleh admin.</p>
                    </div>
                    <?php endif; ?>
                    
                    <form action="<?= site_url('rentals/upload-payment/' . $order['id']) ?>" method="post" enctype="multipart/form-data">
                        <?= csrf_field() ?>
                        <div class="mb-3">
                            <label for="payment_proof" class="form-label">Bukti Pembayaran</label>
                            <input type="file" name="payment_proof" id="payment_proof" class="form-control" accept="image/*" required>
                            <div class="form-text">Upload bukti transfer bank, screenshot, atau konfirmasi pembayaran lainnya.</div>
                        </div>
                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary">Upload Bukti Pembayaran</button>
                        </div>
                    </form>
                    
                    <?php if ($order['payment_method'] == 'bank_transfer'): ?>
                    <div class="mt-4">
                        <h6>Informasi Rekening Bank:</h6>
                        <div class="alert alert-info">
                            <p class="mb-1"><strong>Bank BCA</strong></p>
                            <p class="mb-1">No. Rekening: 1234567890</p>
                            <p class="mb-0">Atas Nama: PT Rental Mobil Indonesia</p>
                        </div>
                        <div class="alert alert-info">
                            <p class="mb-1"><strong>Bank Mandiri</strong></p>
                            <p class="mb-1">No. Rekening: 0987654321</p>
                            <p class="mb-0">Atas Nama: PT Rental Mobil Indonesia</p>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
