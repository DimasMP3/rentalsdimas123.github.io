<?php
// Koneksi ke MySQL
$conn = new mysqli('localhost', 'root', '', 'rentalmobil');

// Cek koneksi
if ($conn->connect_error) {
    // Jika database tidak ada, buat database
    $conn = new mysqli('localhost', 'root', '');
    $conn->query("CREATE DATABASE IF NOT EXISTS rentalmobil");
    $conn->select_db('rentalmobil');
    echo "Database rentalmobil dibuat\n";
}

// Baca file SQL
$sql = file_get_contents('database.sql');

// Pisahkan query berdasarkan semicolon
$queries = array_filter(array_map('trim', explode(';', $sql)), 'strlen');

// Eksekusi setiap query
foreach ($queries as $query) {
    if (!empty($query)) {
        try {
            if ($conn->query($query)) {
                if (stripos($query, 'CREATE TABLE') !== false) {
                    preg_match('/CREATE TABLE.*?(\w+)/i', $query, $matches);
                    if (isset($matches[1])) {
                        echo "Tabel {$matches[1]} berhasil dibuat/diperbaiki\n";
                    }
                }
            }
        } catch (Exception $e) {
            echo "Error pada query: " . $e->getMessage() . "\n";
        }
    }
}

// Import data contoh
$sample_sql = file_get_contents('sample_data.sql');
$sample_queries = array_filter(array_map('trim', explode(';', $sample_sql)), 'strlen');

foreach ($sample_queries as $query) {
    if (!empty($query)) {
        try {
            if ($conn->query($query)) {
                if (stripos($query, 'INSERT INTO') !== false) {
                    preg_match('/INSERT INTO (\w+)/i', $query, $matches);
                    if (isset($matches[1])) {
                        echo "Data berhasil dimasukkan ke tabel {$matches[1]}\n";
                    }
                }
            }
        } catch (Exception $e) {
            echo "Error saat import data: " . $e->getMessage() . "\n";
        }
    }
}

$conn->close();
echo "Selesai!\n";

// Verifikasi tabel
$conn = new mysqli('localhost', 'root', '', 'rentalmobil');
$tables = ['users', 'categories', 'cars', 'orders', 'payments'];

echo "\nVerifikasi tabel:\n";
foreach ($tables as $table) {
    $result = $conn->query("SHOW TABLES LIKE '$table'");
    if ($result->num_rows > 0) {
        $count = $conn->query("SELECT COUNT(*) as count FROM $table")->fetch_assoc()['count'];
        echo "- Tabel '$table' ada dengan $count data\n";
    } else {
        echo "- Tabel '$table' tidak ditemukan\n";
    }
}
$conn->close();
?> 