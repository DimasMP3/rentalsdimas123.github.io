<?php
$conn = new mysqli('localhost', 'root', '', 'rentalmobil');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = file_get_contents('sample_data.sql');

if ($conn->multi_query($sql)) {
    echo "Data contoh berhasil diimpor!";
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?> 