<?php

// Database konfigurasi
$hostname = 'localhost';
$username = 'root';
$password = '';
$database = 'rentals';

// Buat koneksi
$conn = new mysqli($hostname, $username, $password, $database);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Query untuk mendapatkan ringkasan mobil berdasarkan kategori
$sql = "SELECT 
            c.name AS kategori, 
            COUNT(car.id) AS jumlah_mobil,
            MIN(car.daily_rate) AS harga_min,
            MAX(car.daily_rate) AS harga_max,
            AVG(car.daily_rate) AS harga_rata
        FROM 
            cars car
        JOIN 
            categories c ON car.category_id = c.id
        GROUP BY 
            c.id
        ORDER BY 
            c.name";

$result = $conn->query($sql);

echo "===== RINGKASAN DATA MOBIL RENTAL =====\n\n";
echo str_pad("Kategori", 15) . " | " . 
     str_pad("Jumlah Mobil", 15) . " | " . 
     str_pad("Harga Terendah", 20) . " | " . 
     str_pad("Harga Tertinggi", 20) . " | " . 
     "Harga Rata-rata\n";
echo str_repeat("=", 100) . "\n";

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo str_pad($row['kategori'], 15) . " | " . 
             str_pad($row['jumlah_mobil'], 15) . " | " . 
             str_pad("Rp " . number_format($row['harga_min'], 0, ',', '.'), 20) . " | " . 
             str_pad("Rp " . number_format($row['harga_max'], 0, ',', '.'), 20) . " | " . 
             "Rp " . number_format($row['harga_rata'], 0, ',', '.') . "\n";
    }
    
    // Tampilkan total semua
    $total_sql = "SELECT 
                    COUNT(id) AS total_mobil,
                    MIN(daily_rate) AS min_all,
                    MAX(daily_rate) AS max_all,
                    AVG(daily_rate) AS avg_all
                FROM 
                    cars";
    
    $total_result = $conn->query($total_sql);
    $total = $total_result->fetch_assoc();
    
    echo str_repeat("-", 100) . "\n";
    echo str_pad("TOTAL", 15) . " | " . 
         str_pad($total['total_mobil'], 15) . " | " . 
         str_pad("Rp " . number_format($total['min_all'], 0, ',', '.'), 20) . " | " . 
         str_pad("Rp " . number_format($total['max_all'], 0, ',', '.'), 20) . " | " . 
         "Rp " . number_format($total['avg_all'], 0, ',', '.') . "\n";
} else {
    echo "Tidak ada data mobil yang ditemukan.";
}

// Tutup koneksi
$conn->close(); 