<?php

// Database konfigurasi
$hostname = 'localhost';
$username = 'root';
$password = '';
$database = 'rentals';

// Buat koneksi
$conn = new mysqli($hostname, $username, $password, $database);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Mengambil data kategori
$cat_query = "SELECT id, name FROM categories";
$cat_result = $conn->query($cat_query);
$categories = [];

while ($row = $cat_result->fetch_assoc()) {
    $categories[$row['id']] = $row['name'];
}

// Mengambil data mobil
$sql = "SELECT * FROM cars ORDER BY id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "===== DAFTAR MOBIL RENTAL =====\n\n";
    echo str_pad("ID", 5) . " | " . 
         str_pad("Kategori", 12) . " | " . 
         str_pad("Merek", 12) . " | " . 
         str_pad("Model", 15) . " | " . 
         str_pad("Tahun", 6) . " | " . 
         str_pad("Plat Nomor", 15) . " | " . 
         str_pad("Warna", 12) . " | " . 
         str_pad("Harga/Hari (Rp)", 18) . " | " . 
         "Deskripsi\n";
    
    echo str_repeat("=", 120) . "\n";
    
    // Tampilkan data
    while($row = $result->fetch_assoc()) {
        $category = isset($categories[$row['category_id']]) ? $categories[$row['category_id']] : 'Tidak Ada';
        
        echo str_pad($row['id'], 5) . " | " . 
             str_pad($category, 12) . " | " . 
             str_pad($row['brand'], 12) . " | " . 
             str_pad($row['model'], 15) . " | " . 
             str_pad($row['year'], 6) . " | " . 
             str_pad($row['license_plate'], 15) . " | " . 
             str_pad($row['color'], 12) . " | " . 
             str_pad(number_format($row['daily_rate'], 0, ',', '.'), 18) . " | " . 
             substr($row['description'], 0, 50) . "\n";
    }
} else {
    echo "Tidak ada data mobil yang ditemukan.";
}

// Tutup koneksi
$conn->close(); 